﻿using System.Configuration;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TaskKTD.Data;
using TaskKTD.Model;

namespace TaskKTD
{
    public partial class MainWindow : Window
    {
        Context _context = new Context();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LPage_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(Nametxtb.Text) ||
                string.IsNullOrWhiteSpace(Passtxtb.Text))
            {
                MessageBox.Show("Please fill all boxes");
            }

            var query = (from x in _context.User
                        where x.name == Nametxtb.Text && x.password == Passtxtb.Text
                        select x).FirstOrDefault();


            if (query == null)
            {
                Label2.Content = " ";
                Label2.Content = "Invalid name or password." ; 
            }   
            else 
            {
                if (query.role == "employee")
                {
                    Label2.Content = " ";
                    MessageBox.Show("Login Successfully.");
                    EmployeeWindow1 employeeWindow1 = new EmployeeWindow1(query.name);
                    employeeWindow1.Show();
                    this.Close();
                }
                else if (query.role == "Manager")
                {
                    Label2.Content = " ";
                    MessageBox.Show("Login Successfully.");
                    ManagerWindow1 ManagerWindow1 = new ManagerWindow1();
                    ManagerWindow1.Show();
                    this.Close();   
                }

            }
          
        }
    }
}