﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskKTD.Model
{
    internal class task_table
    {
        [Key]
        public int taskId { get; set; }
        public string? title { get; set; }
        public string? description { get; set; }
        public string? status { get; set; }
        public DateTime? dateTime { get; set; }

        [ForeignKey("userId")]
        public int employeeId { get; set; } = 0;
    }
}
