﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskKTD.Model;

namespace TaskKTD.Data
{
    internal class Context  :DbContext
    {
        public Context() { }

        public Context(DbContextOptions options) : base(options) { }

        public DbSet<User> User { get; set; }
        public DbSet<task_table> Task_table { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=ZYAD\\MSSQL__SERVER;Initial Catalog=TaskKTD;Integrated Security=True;Trust Server Certificate=True");
            }
        }
    }
}
