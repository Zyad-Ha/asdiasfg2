﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TaskKTD.Data;

namespace TaskKTD
{

    public partial class EmployeeWindow1 : Window
    {
        Context _context= new Context();
        public EmployeeWindow1(string? Ename)
        {
            InitializeComponent();
            label1.Content = Ename;
            load();

        }
        public EmployeeWindow1()
        {
            InitializeComponent();          

        }

        private void load()
        {
            var thing = _context.Task_table
                .Select(t => new
                {
                    t.taskId,
                    t.title,
                    t.description,
                    t.employeeId,
                    t.status
                }).ToList();
           
            dgPendingTasks.ItemsSource = thing;
             
        }



        
    }
}
